squint([], []).
squint([X|Xs], [Y|Ys]):-
    integer(X), !,
    Y is X * X,
    squint(Xs, Ys).
squint([X|Xs], [X|Ys]):- squint(Xs, Ys).

% base case for compress: two empty list
compress([],[]).
compress([X1|[]],[X1|[]]) :- !.
compress([X1,X2|Y1],[X1|Y2]) :-
    %%unifying the first two elements of the list to X1 and X2.
    %%then comparing, stopping at the first compare.
    X1 \= X2,
    !,
    compress([X2|Y1],Y2).
compress([X1,X1|Y1],Y2) :-
    compress([X1|Y1],Y2).

% helper func for my_flatten
helper([],[],[]).
helper([],[X2|Y2],[X2|Y3]) :-
    helper([],Y2,Y3).
helper([X1|Y1], L,[X1|Y3]) :-
% read through one of the list. add it to Y3. then that list becomes
% empty, so start reading L and add that to Y3
    helper(Y1,L,Y3).

% base case for my_flatten: two empty list
my_flatten([],[]).
% if only one element in the list just print that element and stop.
my_flatten(X,[X]) :- !.
% for several elements:
my_flatten([X1|Y1],H3) :-
    % read the head of the input list and save it in a new list H1
    my_flatten(X1,H1),
    % read the tail of the input list and saves it in a new list H2.
    my_flatten(Y1,H2),
    % using the helper function, combine the two lists: H1 and H2.
    helper(H1,H2,H3).

% base case for pack: two empty list
pack([],[]).
% if input has only one element, add it to its own list and stop.
pack([X1|[]],[[X1|[]]|[]]) :- !.
% unifies first to elements to X1 and X2.
% makes a seperate list for for X1.
pack([X1,X2|Y1],[[X1|[]]|Y3]) :-
% if X1 != X2, then stop and move to the next two elements in the list.
    X1 \= X2,
    !,
    pack([X2|Y1],Y3).
% if the first two elements are the same then add just one of them to
% its own list.
pack([X1,X1|Y1],[[X1|Y2]|Y3]) :-
    pack([X1|Y1],[Y2|Y3]).

% helper func to get the size of the list. size if 0 is list is empty.
size([],0).
% ignore the head, cycle through the tail. every time the head changes
% add 1 to size.
size([_|Y1],S1) :-
    length(Y1,S2),
    S1 is S2 + 1.

% helper function for rlencode
helper2([],[]).
% unifies the first element in the list to X1.
% puts the count and the element in its own list and then adds that list
% to Y2
helper2([X1|Y1],[[X,C]|Y2]) :-
% compares X1 to the head of the list. dont care about the tail
    X1 = [X|_],
% gets the size of the X1 and saves in S.
    size(X1,C),
% recursively calls helper2 on the two lists
    helper2(Y1,Y2).
% takes two lists as input.
rlencode(L1,L3) :-
% packs them into their individuals lists.
    pack(L1,L2),
% uses the helper2 func to get the size of the repetition from pack.
    helper2(L2,L3).

% base case for rldecode: two empty lists
rldecode([],[]).
% if there are 0 occurances of a letter, skips that letter
rldecode([[_,0]|Y1],L) :- !,
    rldecode(Y1,L).
% X1 is the letter. C1 is the count of that letter.
% it adds X1 to the head of the list Y1
rldecode([[X1,C1]|Y1],[X1|Y2]) :- !,
% then decrements the count of X1 by 1
    C2 is C1 - 1,
% recursively calls rldecode with the new count of X1.
    rldecode([[X1,C2]|Y1],Y2).

% base case for range: if the same int is entered, puts that int in the
% head of the list
range(X,X,[X|[]]) :- !.
% X1 is added to the head of the list Y1 and stops.
range(X1,X2,[X1|Y1]) :- !,
% X3 is a new int. it hold the value when X1 is incremented.
    X3 is X1 + 1,
% range is called recursively on the new value of X3.
    range(X3,X2,Y1).



















